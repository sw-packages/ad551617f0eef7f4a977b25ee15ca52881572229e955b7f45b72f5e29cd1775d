// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0/

#pragma once

#if OPENTELEMETRY_ABI_VERSION_NO < 2
#  include <memory>

#  include "opentelemetry/sdk/logs/event_logger_provider.h"
#endif

#include "opentelemetry/version.h"

OPENTELEMETRY_BEGIN_NAMESPACE
namespace sdk
{
namespace logs
{

#if OPENTELEMETRY_ABI_VERSION_NO < 2
/**
 * Factory class for EventLoggerProvider.
 * @deprecated
 */
class OPENTELEMETRY_DEPRECATED EventLoggerProviderFactory
{
public:
  /**
   * Create a EventLoggerProvider.
   */

  static std::unique_ptr<opentelemetry::sdk::logs::EventLoggerProvider> Create();
};
#endif

}  // namespace logs
}  // namespace sdk
OPENTELEMETRY_END_NAMESPACE
